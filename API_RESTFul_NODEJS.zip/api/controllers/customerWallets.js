const uuidv4 = require('uuid/v4');

module.exports = app => {
  const customerWalletsDB = app.data.customerWallets;
  const webviewDB = app.data.webview;
  const webviewDBTwo1 = app.data.v1;
  const webviewDBTwo2 = app.data.v2;
  const webviewDBTwo3 = app.data.v3;
  const webviewDBTwo4 = app.data.v4;
  const controller = {};

  const {
    customerWallets: customerWalletsMock,
  } = customerWalletsDB;

  const {
    webviews: webviewMock,
  } = webviewDB;

  const {
    webviewsegund1: webviewMockTwo1,
  } = webviewDBTwo1;

  const {
    webviewsegund2: webviewMockTwo2,
  } = webviewDBTwo2;

  const {
    webviewsegund3: webviewMockTwo3,
  } = webviewDBTwo3;

  const {
    webviewsegund4: webviewMockTwo4,
  } = webviewDBTwo4;


  controller.listCustomerWallets = (req, res) => res.status(200).json(customerWalletsDB);

  controller.listWebViewOne = (req, res) => {
    const { 
      company_document,
    } = req.query.company_document;

    console.log('=======LISTA DA 1 CHAMADA  '+req.query.company_document)
    res.status(200).json(webviewDB);
  };

  controller.listWebViewTwo = (req, res) => {
    const { 
      restaurant_uuid,
      resquest_id
    } = req.params;
    
    console.log('=====resquest_id======>>  '+resquest_id)

    switch(resquest_id){
      case "c2c35e71-75a1-429a-88f8-d057ac635411":
        res.status(200).json(webviewDBTwo1);
      break;
      case "c2c35e71-75a1-429a-88f8-d057ac635412":
        res.status(200).json(webviewDBTwo2);
      break;
      case "c2c35e71-75a1-429a-88f8-d057ac635413":
        res.status(200).json(webviewDBTwo3);
      break;
      case "c2c35e71-75a1-429a-88f8-d057ac635414":
        res.status(200).json(webviewDBTwo4);
      break;
    }

    
  };

  controller.savewebviews = (req, res) => {
    webviewMockTwo.data.push({
      id: uuidv4(),
      merchant_id: uuidv4(),
      merchantExterna_id: "146036",
      status: "PROCESSING",
      createdAt: "2021-02-10T00:51:32.720Z",
      updatedAt: "2021-02-11T18:11:48.873Z",
      accountNumber: "179793726",
      accountDigit: "5",
      bankNumber: "032",
      branch: "0001",
      channel: "API",
      email: "cariocamixoficial@gmail.com",
      documentNumber: "26055953000140",
      documentType: "CORPORATE",
      acceptanceStatus: "ACCEPTED",
      savingsAccount: false,

    });

    res.status(201).json(webviewMockTwo);
  };

  controller.savewebviews = (req, res) => {
    webviewMock.data.push({
      company_document: uuidv4(),
      request_id: uuidv4(),
      restaurant_id: req.body.name,
      restaurant_uuid: req.body.birthDate,
      business_name: req.body.cellphone,
    });

    res.status(201).json(webviewMock);
  };

  controller.saveCustomerWallets = (req, res) => {
    customerWalletsMock.data.push({
      id: uuidv4(),
      parentId: uuidv4(),
      name: req.body.name,
      birthDate: req.body.birthDate,
      cellphone: req.body.cellphone,
      phone: req.body.phone,
      email: req.body.email,
      occupation: req.body.occupation,
      state: req.body.state,
    });

    res.status(201).json(customerWalletsMock);
  };

  controller.removeCustomerWallets = (req, res) => {
    const {
      customerId,
    } = req.params;

    const foundCustomerIndex = customerWalletsMock.data.findIndex(customer => customer.id === customerId);

    if (foundCustomerIndex === -1) {
      res.status(404).json({
        message: 'Cliente não encontrado na base.',
        success: false,
        customerWallets: customerWalletsMock,
      });
    } else {
      customerWalletsMock.data.splice(foundCustomerIndex, 1);
      res.status(200).json({
        message: 'Cliente encontrado e deletado com sucesso!',
        success: true,
        customerWallets: customerWalletsMock,
      });
    }
  };

  controller.updateCustomerWallets = (req, res) => {
    const { 
      customerId,
    } = req.params;

    const foundCustomerIndex = customerWalletsMock.data.findIndex(customer => customer.id === customerId);

    if (foundCustomerIndex === -1) {
      res.status(404).json({
        message: 'Cliente não encontrado na base.',
        success: false,
        customerWallets: customerWalletsMock,
      });
    } else {
      const newCustomer = {
        id: customerId ,
        parentId: req.body.parentId,
        name: req.body.name,
        birthDate: req.body.birthDate,
        cellphone: req.body.cellphone,
        phone: req.body.phone,
        email: req.body.email,
        occupation: req.body.occupation,
        state: req.body.state,
        createdAt: new Date()
      };
      
      customerWalletsMock.data.splice(foundCustomerIndex, 1, newCustomer);
      
      res.status(200).json({
        message: 'Cliente encontrado e atualizado com sucesso!',
        success: true,
        customerWallets: customerWalletsMock,
      });
    }
  }

  return controller;
}