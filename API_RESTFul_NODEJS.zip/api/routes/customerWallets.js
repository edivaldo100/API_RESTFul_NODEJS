module.exports = app => {
  const controller = app.controllers.customerWallets;

  app.route('/v1/restaurants/:restaurant_uuid/webview/:resquest_id/status')
  .get(controller.listWebViewTwo)

  app.route('/v1/webview/onboarding/:companyDocument/company')
  .get(controller.listWebViewOne)

  app.route('/v1/restaurants/webview/info')
  .get(controller.listWebViewOne)

  app.route('/api/v1/customer-wallets')
    .get(controller.listCustomerWallets)
    .post(controller.listWebViewOne);

  app.route('/api/v1/customer-wallets/:customerId')
    .delete(controller.removeCustomerWallets)
    .put(controller.updateCustomerWallets);
}